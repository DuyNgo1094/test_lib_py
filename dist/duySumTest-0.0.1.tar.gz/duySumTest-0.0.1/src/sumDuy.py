def sumDuyNgo(a, b):
    return f"{a + b} Duy Ngo Dep Trai"