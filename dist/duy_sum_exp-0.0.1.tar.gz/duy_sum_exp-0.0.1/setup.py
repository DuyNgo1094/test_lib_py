import setuptools

setuptools.setup(
    name="duy_sum_exp",
    version="0.0.1",
    author="Ngo Van Duy",
    author_email="duyngo@example.com",
    description="Sort description",
    long_description="Full description",
    long_description_content_type="text/markdown",
    url="https://github.com/DuyNgo1094/test_lib_py",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 2",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
